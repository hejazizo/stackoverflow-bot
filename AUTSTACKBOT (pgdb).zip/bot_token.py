import telebot
token = 'put your token here'

bot = telebot.TeleBot(token= token, threaded=False)