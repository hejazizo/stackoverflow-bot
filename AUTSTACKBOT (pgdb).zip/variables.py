report_question_limit = 3
report_user_limit = 3

limit_line = 5
limit_length = limit_line * 10
limit_char = limit_length * 10

question_point = 5
answer_point = 5
accepted_answer_point = 20
report_question_point = -20
report_user_point = -20

admins = ['Jahanshahi_amir', 'Ali_H93']
valid_roles = ['STUDENT', 'TA', 'ADMIN']

instant_report_roles = ['ADMIN']
vip = ['ADMIN', 'TA']
